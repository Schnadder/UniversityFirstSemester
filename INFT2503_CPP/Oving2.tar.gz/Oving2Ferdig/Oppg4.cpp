
#include <iostream>

using namespace std;

int main()
{
	int a = 5;
	int& b = a; // Referansen maa referere til en variabel, kan ikke intialiseres uten aa referere til noe
	int* c;
	c = &b;
	a = b + *c; // a og b er ikke pointer saa det blir feil aa bruke *a ettersom dette gir verdien som a peker paa
	b = 2; // b er en int ikke en pointer saa det gir ikke mening aa sette &b lik noe

	cout << "a " << a << "\n";
	cout << "b " << b << "\n";
	cout << "c " << *c << "\n";
	return 0;
}
